//
//  ViewController.swift
//  18 - 购物车动画
//
//  Created by meng on 16/1/21.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

extension UIColor{
    
    class func randomColor() -> UIColor{
        
        // 随机RGB
        let R = (CGFloat(arc4random_uniform(255)) + 1) / CGFloat(255.0)
        let G = (CGFloat(arc4random_uniform(255)) + 1) / CGFloat(255.0)
        let B = (CGFloat(arc4random_uniform(255)) + 1) / CGFloat(255.0)
        
       return  UIColor(red: R, green: G, blue: B, alpha: 1.0)
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var endBtn: UIButton!
    
    @IBOutlet weak var beginBtn: UIButton!
    
    // 动画的layer
    
    var aniamateLayer: CALayer?
    
    // 贝塞尔路径
    private lazy var animatePath: UIBezierPath = {
        let i = UIBezierPath()
        let startPoint = self.beginBtn.center
        
        i.moveToPoint(startPoint)
        let endPoint = self.endBtn.center
        
        let sx = startPoint.x
        let sy = startPoint.y
        
        let ex = endPoint.x
        let ey = endPoint.y
        
        let cx = sx + (ex - sx) / CGFloat(3)
        let cy = sy + (ey - sy) * CGFloat(0.5) - CGFloat(400)
        
        i.addQuadCurveToPoint(endPoint, controlPoint: CGPointMake(cx, cy))
        
        return i
    }()


    @IBAction func click(sender: AnyObject) {

        aniamateLayer = CALayer()
        
        aniamateLayer!.backgroundColor = UIColor.randomColor().CGColor
        aniamateLayer!.bounds = CGRectMake(0, 0, 20, 20)
        aniamateLayer!.cornerRadius = 10
        aniamateLayer!.masksToBounds = true
        aniamateLayer!.position = self.beginBtn.center
        aniamateLayer!.anchorPoint = CGPointMake(0.5, 0.5)
        
        view.layer.addSublayer(aniamateLayer!)
        
        groupAnimate()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    /**
     组动画: 这里为了简单操作，就用一个动画，其实淘宝，哪些复杂的动画都是通过组动画完成的
     */
    func groupAnimate(){
        
        // 路线
        let pathAnimation = CAKeyframeAnimation(keyPath: "position")
        pathAnimation.path = animatePath.CGPath
        pathAnimation.duration = 0.7
        pathAnimation.fillMode = kCAFillModeForwards
        pathAnimation.removedOnCompletion = false
        // 存放的在数组中
        pathAnimation.timingFunctions = [CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseIn)]
        aniamateLayer!.addAnimation(pathAnimation, forKey: nil)
        
        // 延时操作
        performSelector("removeLayer:", withObject: self.aniamateLayer, afterDelay: 0.76)
    }
    
    func removeLayer(obj:CALayer){
        obj.removeFromSuperlayer()
    }

}

