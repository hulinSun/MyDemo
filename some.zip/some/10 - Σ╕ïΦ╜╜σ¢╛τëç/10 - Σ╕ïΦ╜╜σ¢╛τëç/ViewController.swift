//
//  ViewController.swift
//  10 - 下载图片
//
//  Created by meng on 16/1/5.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    // http://pic.yesky.com/uploadImages/2015/311/45/60J6J4TM39TS.JPG
    
    private lazy var imageUrl: NSURL? = {
        let i = NSURL(string: "http://pic.yesky.com/uploadImages/2015/311/45/60J6J4TM39TS.JPG")
        return i
    }()
    
    var image: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
        imgView.contentMode = .Center

    }
    
    /**
     下载图片方式1
     */
    func downLoad1(){
        
        print(NSThread.currentThread()) // 子线程
        
        let data = NSData(contentsOfURL: imageUrl!)
        if let d = data{
            image = UIImage(data: d)
        }
        
        // swift 中只要在闭包中使用了self 。都必须显示的用self 调用，为了防止闭包的循环应用
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.imgView.image = self.image
        }
    }
    
    
    /**
     下载图片2
     */
    func downLoad2(){
        
        dispatch_async(dispatch_get_global_queue(0, 0)) { () -> Void in
            // 下载图片
            let data = NSData(contentsOfURL: self.imageUrl!)
            if let d = data{
                self.image = UIImage(data: d)
            }
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.imgView.image = self.image!
            })
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        // 在子线程执行
//        performSelectorInBackground("downLoad1", withObject: nil)
        
//        let thread = NSThread(target: self, selector: "downLoad1", object: nil)
//        thread.start()
        
        downLoad2()

    }
    
    
}

