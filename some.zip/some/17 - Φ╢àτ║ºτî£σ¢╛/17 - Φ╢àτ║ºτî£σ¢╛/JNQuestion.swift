//
//  JNQuestion.swift
//  17 - 超级猜图
//
//  Created by meng on 16/1/16.
//  Copyright © 2016年 meng. All rights reserved.
//

import Foundation


// 问题

class JNQuestion {
    
    var answer: String?
    var icon: String?
    var title: String?
    var options:[String]?
    
    init(dict:[String: AnyObject]){
        
        self.answer = dict["answer"] as? String
        self.icon = dict["icon"] as? String
        self.title = dict["title"] as? String
        self.options = dict["options"] as?[String]
    }
    
}