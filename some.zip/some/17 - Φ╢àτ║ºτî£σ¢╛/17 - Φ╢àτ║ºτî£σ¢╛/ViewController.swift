//
//  ViewController.swift
//  17 - 超级猜图
//
//  Created by meng on 16/1/16.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController , JNOptionViewDelegate {

    var index: Int = -1
    
    /** 标记是否是大图 */
    var bigImage:Bool = false
    
    // 计算属性，存储这所有的存储
    var allOption: [String] {
        get{
            var tempAll = [String]()
            // 遍历
            for i in 0..<answerView.subviews.count{
                //取出按钮
                let btn = answerView.subviews[i] as! UIButton
                if let tte = btn.currentTitle{
                    tempAll.append(tte)
                }
            }
            print(tempAll)
            return tempAll
        }
    }
    
    // 计算属性。判断满没满
    var full: Bool{
        get{
            if allOption.count < questions[index].answer?.characters.count{
                return false
            }else{
                return true
            }

        }
    }

    private let animationDuration = 0.25
    /** 索引label */
    @IBOutlet weak var indexLabel: UILabel!
    
    /** 描述 */
    @IBOutlet weak var descLabel: UILabel!
    
    /** 中间的图片 */
    @IBOutlet weak var pictureView: UIButton!
    
    /** 帮助按钮 */
    @IBOutlet weak var helpButton: UIButton!
    
    /** 提示按钮 */
    @IBOutlet weak var tipButton: UIButton!
    
    /** 大图 按钮 */
    @IBOutlet weak var bigImageButton: UIButton!
    
    /** 下一题 */
    @IBOutlet weak var nextButton: UIButton!
    
    private lazy var cover: UIView = {
        let i = UIView(frame: self.view.bounds)
        i.backgroundColor = UIColor.blackColor()
        i.alpha = 0.0
        
        // 添加手势
        let tap = UITapGestureRecognizer(target: self, action: "tapCover")
        i.addGestureRecognizer(tap)
        return i
    }()

    private lazy var optionView: JNOptionView = {
        let op: JNOptionView = JNOptionView(frame:CGRectMake(0, CGRectGetMaxY(self.answerView.frame), self.view.frame.size.width, 300))
        self.view.addSubview(op)
        op.delegate = self
        return op
    }()

    
    private lazy var answerView: JNAnswerView = {
        let a: JNAnswerView = JNAnswerView(frame: CGRectMake(0, CGRectGetMaxY(self.pictureView.frame) + 10, self.view.bounds.width, 50))
        self.view.addSubview(a)
    
        //[weak self]
        a.block = {btn  in // 参数，返回值 ，如果有参数，那么久放在参数之前，如果没参数，那么放在in 前面
            
            // 遍历可选
            for i in 0..<self.optionView.options.count{
                
                // 取出title
                if btn.currentTitle == self.optionView.options[i]{
                    // 取出optionView 的第i 个
                    self.optionView.subviews[i].hidden = false
                    btn.setTitle(nil, forState: .Normal)
                    break
                }
            }
        }
        return a
    }()

    /** 数据数组 */
    private lazy var questions: [JNQuestion] = {
        if let file = NSBundle.mainBundle().pathForResource("questions.plist", ofType: nil){
            
            let tempArr: Array = NSArray(contentsOfFile: file) as![[String: AnyObject]]
            
            // 用map 函数，显得专业一点
            return tempArr.map{item in JNQuestion(dict: item)}
        }
        // 如果file 没有值，那么返回一个空数组
        return [JNQuestion]()
    }()
    
    func tapCover(){
        
        UIView.animateWithDuration(animationDuration, animations: { () -> Void in
            self.pictureView.transform = CGAffineTransformIdentity
            self.bigImage = false
            }) { (completed) -> Void in
            self.cover.removeFromSuperview()
        }
    }

    /**
     提示
     */
    @IBAction func tip() {
         print("点击了提示")
    }
    
    /**
     帮助
     */
    @IBAction func help() {
         print("点击了帮助")
    }
    /**
     大图
     */
    @IBAction func big() {
        // 先显示遮盖
        view.addSubview(cover)
        
        // 提到最外面
        view.bringSubviewToFront(pictureView)
        UIView.animateWithDuration(animationDuration, animations: { () -> Void in
            self.pictureView.transform = CGAffineTransformMakeScale(2.0, 2.0)
            self.bigImage = true
            self.cover.alpha = 0.5
        })
    }
    /**
     下一题
     */
    @IBAction func next() {
        index++
        
        let question = questions[index]
        
        indexLabel.text = String(format: "%d/%d", index + 1,questions.count)
        descLabel.text = question.title
       
        pictureView.setBackgroundImage(UIImage(named:question.icon!), forState: .Normal)
        
        nextButton.enabled = index != 9

        if let answer = question.answer{
            answerView.answerCount = answer.characters.count
        }
        
        if let options = question.options{
            optionView.options = options
        }
    }
    /**
     中间图片的切换
     */
    @IBAction func picChange() {
        
        if bigImage { // 是大图片
            tapCover()
        }else{
            big()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pictureView.layer.shadowColor = UIColor.whiteColor().CGColor
        pictureView.layer.shadowOffset = CGSizeMake(3, 3)
        pictureView.layer.shadowOpacity = 1

        next()
    }
    
    //MARK: JNOptionViewDelegate
    
    func optionViewDidClickOption(option: UIButton) {
        
        option.hidden = true
        
        for i in 0..<answerView.answerCount{
            // 取出
            let btn = answerView.subviews[i] as! UIButton
            if btn.currentTitle == nil { // 为空
                btn.setTitle(option.currentTitle, forState: .Normal)
                btn.setTitleColor(UIColor.blackColor(), forState: .Normal)
                break
            }
        }
        
        if full{
            // 判断答案是否正确
            var ans = ""
            for item in allOption{
                ans = ans + item
            }
            
            // 答案
            if ans == questions[index].answer{
                correct()
            }else{
               incorrect()
            }
            
        }else{

        }
    }
    
    /**
     答案正确的处理
     */
    func correct(){
        
        for i in 0..<self.answerView.subviews.count{
            let btn = self.answerView.subviews[i] as! UIButton
            btn.setTitleColor(UIColor.redColor(), forState: .Normal)
        }
        
        if nextButton.enabled {
            self.performSelector("next", withObject: nil, afterDelay: 1)
        }
    }
    
    /**
     答案错误的处理
     */
    func incorrect(){
        for i in 0..<self.answerView.subviews.count{
            let btn = self.answerView.subviews[i] as! UIButton
            btn.setTitleColor(UIColor.blueColor(), forState: .Normal)
        }
        
    }
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .LightContent
    }
}

