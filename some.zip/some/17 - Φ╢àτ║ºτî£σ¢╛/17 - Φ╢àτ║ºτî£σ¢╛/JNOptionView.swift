//
//  JNOptionView.swift
//  17 - 超级猜图
//
//  Created by meng on 16/1/17.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

@objc protocol JNOptionViewDelegate{
    optional func optionViewDidClickOption(option: UIButton)
}

class JNOptionView: UIView {

    var options: [String] = [String](){
        
        didSet{
            // 创建子控件
            setup()
        }
    }
    
    var delegate:JNOptionViewDelegate?
    
    /**
     初始化子控件
     */
    func setup(){
        
        self.subviews.forEach{$0.removeFromSuperview()}
        
        for i in 0..<options.count{
            
            // 取出这个可选答案
            let opt = options[i]
            let v = UIButton()
            v.tag = i
            v.addTarget(self, action: "optionClick:", forControlEvents: .TouchUpInside)
            
            v.backgroundColor = UIColor.whiteColor()
            v.setTitle(opt, forState: .Normal)
            v.setTitleColor(UIColor.blackColor(), forState: .Normal)
            self.addSubview(v)
        }
        
    }
    
    func optionClick(btn: UIButton){        
        delegate?.optionViewDidClickOption?(btn)// 通知代理
        
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        
        // 布局子控件
        super.layoutSubviews()
        
        let width: CGFloat = 35
        let height: CGFloat = 35
        let maxCols: CGFloat = 7 // 七列
        let margin: CGFloat = (self.frame.size.width - maxCols * width) / (maxCols + 1)
        
        for i in 0..<self.subviews.count{
            // 取出子控件
            let v = self.subviews[i]
            
            // 计算行号。 列好
            let row = i / Int(maxCols)
            let col = i % Int(maxCols)
            
            let x = margin + (margin + width) * CGFloat(col)
            let y = margin + (margin + height) * CGFloat(row)
            
            v.frame = CGRectMake(x, y, width, height)
        }
    }
}
