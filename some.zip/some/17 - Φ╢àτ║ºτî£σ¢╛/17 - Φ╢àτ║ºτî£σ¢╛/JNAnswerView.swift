//
//  JNAnswerView.swift
//  17 - 超级猜图
//
//  Created by meng on 16/1/17.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class JNAnswerView: UIView {
    
    // 给外界提供一个接口，给我有多少个子，我创建几个小格子给你
    
    var answerCount:Int = 0{ // 存储属性
        didSet{
            // 这个时候我知道了有几个小格子，那么我就创建子控件
            setup()
        }
    }
    
    // 闭包回调
    typealias answerClickBlock = (button: UIButton)->()
    
    var block: answerClickBlock?
    
    /**
     初始化子控件
     */
    func setup(){
        
        // 移除之前的
        self.subviews.forEach{$0.removeFromSuperview()}
        
        for i in 0..<self.answerCount{
            let v = UIButton()
            v.addTarget(self, action:"btnClick:", forControlEvents: UIControlEvents.TouchUpInside)
            v.backgroundColor = UIColor.whiteColor()
            v.tag = i
            self.addSubview(v)
        }
    }
    
    
    func btnClick(btn:UIButton){
        
        block?(button: btn) // 如果block 有值，那么久调用成功，没有值，可选连失败
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        // 宽高
        let width: CGFloat = 40.0
        let height = width
        let y: CGFloat = 5
        let margin: CGFloat = 15.0
        
        let padding = (self.frame.size.width  - (CGFloat(self.answerCount - 1) * (margin + width) + width)) * 0.5
        
        // 取出子控件
        for i in 0..<self.subviews.count{
            let v = self.subviews[i]
            
            let x = padding + (margin + width) * CGFloat(i)
            v.frame = CGRectMake(x, y, width, height)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
