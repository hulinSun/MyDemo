//
//  ViewController.swift
//  04 - 团购
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class Deal {
    var icon:String?
    var price:String?
    var title:String?
    var buyCount:String?
    
    init(dict:[String:String]){
        
        self.icon = dict["icon"]
        self.price = dict["price"]
        self.buyCount = dict["buyCount"]
        self.title = dict["title"] //  as! String 因为 字典是[String:String] 类型的。而不是[:anyobj] 类型的
    }
}

class ViewController: UITableViewController {

    private lazy var deals:[Deal] = {
        var ds:[Deal] = [Deal]()
        if let file = NSBundle.mainBundle().pathForResource("deals.plist", ofType: nil){
            let tempArr: NSArray = NSArray(contentsOfFile: file)!
            
            for item in tempArr as![[String:String]]{ // 数组，数组里装的是[string:string]字典
                let d:Deal = Deal(dict: item)
                ds.append(d)
            }
        }
        return ds
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 80
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = JNDealViewCell.cellWithTableView(tableView) 
        cell.deal = deals[indexPath.row]
        return cell
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return deals.count
    }
    
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == UITableViewCellEditingStyle.Delete { // 删除
            deals.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Left)
        }
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
}

