//
//  JNDealViewCell.swift
//  04 - 团购
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class JNDealViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // 图片
    private lazy var iconView: UIImageView = {
        var i = UIImageView()
        return i
    }()
    
    // 标题
    private lazy var nameLable: UILabel = {
        var n = UILabel()
        n.textAlignment = .Left
        n.textColor = UIColor.blackColor()
        return n
    }()
    
    // 价格
    private lazy var priceLable: UILabel = {
        var p = UILabel()
        p.textColor = UIColor.orangeColor()
        return p
    }()
    
    // 购买数
    private lazy var buyLabel: UILabel = {
        var b = UILabel()
        b.textColor = UIColor.lightGrayColor()
        b.textAlignment = .Right
        return b
    }()
    
    var deal: Deal? { // 存储属性
        didSet{
            // 设置值
            nameLable.text = deal?.title
            iconView.image = UIImage(named: (deal?.icon)!)
            buyLabel.text = String(format: "%@人已购买", (deal?.buyCount)!)
            priceLable.text = String(format: " ￥ %@", (deal?.price)!)
        }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI(){
        
        contentView.addSubview(iconView)
        contentView.addSubview(nameLable)
        contentView.addSubview(priceLable)
        contentView.addSubview(buyLabel)
        
        nameLable.font = UIFont.systemFontOfSize(14)
        priceLable.font = UIFont.systemFontOfSize(13)
        buyLabel.font = UIFont.systemFontOfSize(13)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        iconView.frame = CGRectMake(10, 10, 80, 60)
        nameLable.frame = CGRectMake(CGRectGetMaxX(iconView.frame) + 10, 10, 150, 20)
        priceLable.frame = CGRectMake(nameLable.frame.origin.x, CGRectGetMaxY(nameLable.frame) + 10, 100, 30)
        buyLabel.frame = CGRectMake(self.frame.size.width - 120, priceLable.frame.origin.y, 100, 20)
    }
    
    static func cellWithTableView(tableview: UITableView)-> JNDealViewCell{
        let ident = "cell"
        var cell = tableview.dequeueReusableCellWithIdentifier(ident) as? JNDealViewCell
        if cell == nil{
            cell = JNDealViewCell(style: .Default, reuseIdentifier: ident)
        }
        return cell!
    }
}
