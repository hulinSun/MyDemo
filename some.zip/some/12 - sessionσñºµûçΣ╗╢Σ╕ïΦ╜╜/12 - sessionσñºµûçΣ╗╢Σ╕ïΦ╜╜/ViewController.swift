//
//  ViewController.swift
//  12 - session大文件下载
//
//  Created by meng on 16/1/12.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController , NSURLSessionDownloadDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        download()
    }
    
    /**
     大文件下载
     */
    func download(){
        
        let cfg = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        let session = NSURLSession(configuration: cfg, delegate: self, delegateQueue: NSOperationQueue())
        
        let task = session.downloadTaskWithURL(NSURL(string: "http://120.25.226.186:32812/resources/videos/minion_01.mp4")!)
        task.resume()
    }
    
    //MARK: 代理方法
    
    // 下载完毕
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didFinishDownloadingToURL location: NSURL) {
        
        // 剪切
        let file = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true).last
        if let f = file{
            var ocf = f as NSString
            
            ocf = ocf.stringByAppendingPathComponent((downloadTask.response?.suggestedFilename)!)
            
            let fileMgr = NSFileManager.defaultManager()
            
            do{
                try fileMgr.moveItemAtURL(location, toURL: NSURL(fileURLWithPath: ocf as String))
                print(ocf)
            }catch _{
                 print("catch error")
            }
        }
    }
    
    /**
     * 每当写入数据到临时文件时，就会调用一次这个方法
     * totalBytesExpectedToWrite:总大小
     * totalBytesWritten: 已经写入的大小
     * bytesWritten: 这次写入多少
     */
    
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        
        let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
         print("totalBytesExpectedToWrite-----下载进度 \(progress)")
    }
}

