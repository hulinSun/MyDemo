//
//  TableViewCell.h
//  06 - 自定义cell(代码)
//
//  Created by meng on 15/12/31.
//  Copyright © 2015年 meng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@end
