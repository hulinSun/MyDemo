//
//  JNDealCell.swift
//  06 - 自定义cell(代码)
//
//  Created by meng on 15/12/31.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class JNDealCell: UITableViewCell {

    @IBOutlet weak var photoView: UIImageView!
    @IBOutlet weak var descView: UILabel!
    
    @IBOutlet weak var vipView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var iconView: UIImageView!
    
    weak var cellDelegate: JNDealCellDelegate?
    
    // 闭包回调
    typealias photoClickBlock = (cell: JNDealCell)->()
    
    // 可能有也可能没有
    var block: photoClickBlock?
    
    // 虽然数据不一致，但是依然可以用autolayout 来搞事情
    var cellHeight:CGFloat{
        if photoView.hidden == true{
            
            return CGRectGetMaxY(descView.frame) + CGFloat(10)
        }else{
            return CGRectGetMaxY(photoView.frame) + CGFloat(10)
        }
    }
    
    var status:Status?{
        
        didSet{
            guard status == nil else{
                
                nameLabel.text = status?.name
                descView.text = status?.text
                iconView.image = UIImage(named: (status?.icon)!)
                
                if status?.vip == 1{
                    nameLabel.textColor = UIColor.redColor()
                    vipView.hidden = false
                }else{
                    nameLabel.textColor = UIColor.orangeColor()
                    vipView.hidden = true
                }
                
                if status?.picture == nil{
                    photoView.hidden = true
                    
                }else{
                    photoView.image = UIImage(named: (status?.picture)!)
                    photoView.backgroundColor = UIColor.redColor()
                    photoView.hidden = false
                }
                
                return
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        descView.numberOfLines = 0
        descView.preferredMaxLayoutWidth = UIScreen.mainScreen().bounds.size.width - 20
        iconView.layer.cornerRadius = 4
        iconView.clipsToBounds = true
        vipView.image = UIImage(named: "vip")
        
        photoView.userInteractionEnabled = true
        iconView.userInteractionEnabled = true
        
        // 添加手势
        let tapIcon = UITapGestureRecognizer(target: self, action: "tapIcon")
        iconView.addGestureRecognizer(tapIcon)
        
        let tapPhoto = UITapGestureRecognizer(target: self, action: "tapPhoto")
        photoView.addGestureRecognizer(tapPhoto)
    }
    
    /**
     点击了配图
     */
    func tapPhoto(){
        guard block == nil else{
            block!(cell: self) // 传递值
            return
        }
    }
    
    /**
     点击了头像
     */
    func tapIcon(){
        cellDelegate?.tapIcon?(self) // 通知代理
    }

    static func cellWithTableView(tableview:UITableView)-> JNDealCell{
        let ider = "cell"
        let cell = tableview.dequeueReusableCellWithIdentifier(ider) as?JNDealCell
      
        return cell!
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
