//
//  JNDealCellDelegate.swift
//  06 - 自定义cell(代码)
//
//  Created by meng on 16/1/7.
//  Copyright © 2016年 meng. All rights reserved.
//

import Foundation

@objc
protocol JNDealCellDelegate {
    optional func tapIcon(cell: JNDealCell) // 传出cell
}