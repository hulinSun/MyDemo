//
//  ViewController.swift
//  05 - 动态高度
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class Status {
    
    var name: String?
    var icon: String?
    var text: String?
    var picture: String?
    var vip: Int?
    init(dict: [String: AnyObject]){
        
        self.name = dict["name"] as?String
        self.icon = dict["icon"] as?String
        self.text = dict["text"] as?String
        self.picture = dict["picture"] as?String
        self.vip = dict["vip"] as?Int
    }
}


class ViewController: UITableViewController,JNDealCellDelegate {
    
    private lazy var statuses: [Status] = {
        var i = [Status]()
        
        if let file = NSBundle.mainBundle().pathForResource("statuses.plist", ofType: nil){
            
            let tempArr: NSArray = NSArray(contentsOfFile: file)!
            
            for item in tempArr as![[String: AnyObject]]{
                let s: Status = Status(dict: item)
                i.append(s)
            }
        }
        return i
    }()
    
    private lazy var savedH: [Int: CGFloat] = { // 缓存高度的字典
        let i = [Int: CGFloat]()
        return i
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.registerNib(UINib(nibName: "JNDealCell", bundle: nil), forCellReuseIdentifier: "cell")
        
//        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
        override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return statuses.count
        }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = JNDealCell.cellWithTableView(tableView)
        
        cell.block = {cell in
            print("在控制器知道了点击cell \(cell.status?.name)")
        }
        
        cell.cellDelegate = self
        cell.status = statuses[indexPath.row]
        
        //MARK: 重新布局，算出高度，关键
        cell.layoutIfNeeded() // 一定要提前更新布局，布局完毕之后，那么我才开始计算准确的值
        
        savedH[indexPath.row] = cell.cellHeight
        
        return cell
    }
    
    /**
    返回每一行的估计高度
     - parameter : 只要返回了估计高度，那么就会先调用tableView:cellForRowAtIndexPath:方法创建cell，再调用tableView:heightForRowAtIndexPath:方法获取cell的真实高度
    */
    
    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 200
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return savedH[indexPath.row]!
    }
    
    //MARK: 自定义代理
    func tapIcon(cell: JNDealCell) {
        print("在控制器中知道了点击了头像----代理 \(cell.status?.name)")
    }
}

