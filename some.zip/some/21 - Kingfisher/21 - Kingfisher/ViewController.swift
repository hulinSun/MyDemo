//
//  ViewController.swift
//  21 - Kingfisher
//
//  Created by meng on 16/1/25.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit
import Kingfisher


let cellid = "cell"

class JNApp: NSObject {
    
    var name: String?
    var icon: String?
    var download: String?
    
    init(dict:[String: AnyObject]){
        super.init()
        
        self.setValuesForKeysWithDictionary(dict)
    }
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
//        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: cellid)
        tableView.rowHeight = 60
    }
    
    private lazy var tableView: UITableView = {
        let i = UITableView(frame: self.view.bounds)
        i.dataSource = self
        return i
    }()
    
    private lazy var apps: [JNApp] = {
        
        if let file = NSBundle.mainBundle().pathForResource("apps.plist", ofType: nil){
            let ocarray: NSArray = NSArray(contentsOfFile: file)!
           return ocarray.map{JNApp(dict: $0 as! [String : AnyObject])}
        }
        return [JNApp]()
    }()


}


//MARK: UITableViewDataSource
extension ViewController: UITableViewDataSource{
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apps.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier(cellid)
        
        if cell == nil{
            cell = UITableViewCell(style: .Subtitle, reuseIdentifier: cellid)
        }
        
        // 取出app
        let app = apps[indexPath.row]
        cell!.textLabel?.text = app.name
        cell!.detailTextLabel?.text = app.download
        cell?.detailTextLabel?.textColor = UIColor.redColor()
        
        // 简单粗暴
//        cell?.imageView?.kf_setImageWithURL(NSURL(string: app.icon!)!)
        
        // 有展位图片
//        cell?.imageView?.kf_setImageWithURL(NSURL(string: app.icon!)!, placeholderImage: UIImage(named: "coin")) // 注意这里的展位图片最好尺寸要保持一致
        
        // 下载选项
        cell?.imageView?.kf_setImageWithURL(NSURL(string: app.icon!)!, placeholderImage: UIImage(named: "50"), optionsInfo: [.Transition(ImageTransition.Fade(1))])
        
        // 回调
//        cell?.imageView?.kf_setImageWithURL(<#T##URL: NSURL##NSURL#>, placeholderImage: <#T##Image?#>, optionsInfo: <#T##KingfisherOptionsInfo?#>, completionHandler: <#T##CompletionHandler?##CompletionHandler?##(image: Image?, error: NSError?, cacheType: CacheType, imageURL: NSURL?) -> ()#>)
        
        // 下载进度 + 回调
//        cell?.imageView?.kf_setImageWithURL(<#T##URL: NSURL##NSURL#>, placeholderImage: <#T##Image?#>, optionsInfo: <#T##KingfisherOptionsInfo?#>, progressBlock: <#T##DownloadProgressBlock?##DownloadProgressBlock?##(receivedSize: Int64, totalSize: Int64) -> ()#>, completionHandler: <#T##CompletionHandler?##CompletionHandler?##(image: Image?, error: NSError?, cacheType: CacheType, imageURL: NSURL?) -> ()#>)
        
        return cell!
    }
    
}

