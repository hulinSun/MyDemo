//
//  JNPerson.m
//  01 - swift引用oc
//
//  Created by meng on 16/1/27.
//  Copyright © 2016年 meng. All rights reserved.
//

#import "JNPerson.h"

@implementation JNPerson

-(void)run{
    NSLog(@"person ---run");
}

+(void)eat{
    NSLog(@"person +++++eat");
}

-(NSString *)description
{
    return [NSString stringWithFormat:@"name = %@ ,age = %d",self.name, self.age];
}

@end
