//
//  ViewController.swift
//  01 - swift引用oc
//
//  Created by meng on 16/1/27.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        personTet()
    }
    
    func personTet(){
        
        let p = JNPerson()
        
        p.name = "孙虎林"
        p.age = 22
        
        print(p.description)
        
        p.run()
        JNPerson.eat()
        
        // swift 项目引用oc 文件很简单。当创建oc 文件的时候，系统会自动创建一个桥接文件。
        
        /**
        Swift代码引用OC，需依靠 Objective-C bridging header 将相关文件暴露给Swift。
        创建 Objective-C bridging header 有两种方法：
        1、当你在Swift项目中尝试创建OC文件时，系统会自动帮你创建 Objective-C bridging header .
        2. 自己创建 Objective-C bridging header
        File > New > File > (iOS or OS X) > Source > Header File
        切记，名字 一定要 是 项目工程名-Bridging-Header.
        */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

