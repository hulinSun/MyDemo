//
//  JNPerson.h
//  01 - swift引用oc
//
//  Created by meng on 16/1/27.
//  Copyright © 2016年 meng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JNPerson : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,assign)int age;

-(void)run;

+(void)eat;

@end
