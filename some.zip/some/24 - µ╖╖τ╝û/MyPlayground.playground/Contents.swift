//: Playground - noun: a place where people can play

import UIKit


/*:
* 在注释的后面加上： editor 用markdown 用法包装(有逼格的玩法)
* 这是注释
*/
var str = "Hello, playground"
