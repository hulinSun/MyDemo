//
//  ViewController.m
//  02 - oc引用swift
//
//  Created by meng on 16/1/27.
//  Copyright © 2016年 meng. All rights reserved.
//

#import "ViewController.h"

#import "test-swift.h" // 地方有时候会报错，编译一下就ok 了


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     *  1.在工程的 Build Settings 中把 defines module 设为 YES.
     *  2.把 product module name 设置为项目工程的名字。
     *  3.在你的OC文件中导入 ProjectName-Swift.h.
     */
    
    /** oc 调用swift
     *  1. targets->build settings ->packing->Product Module Name 中设置模块名，这个名称很重要 swift 的头文件就是根据这个来命名的。
     *
     */
    JNPerson *p = [[JNPerson alloc]initWithName:@"孙虎林" age:22 score:100];
    [p run];

    NSLog(@"---%@",p.description);
    [JNPerson eat];
    
}

@end
