//
//  JNPerson.swift
//  02 - oc引用swift
//
//  Created by meng on 16/1/27.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class JNPerson: NSObject {
    var name: String
    var age: Int
    var score: Int
    
    // description 在swift 中不再是一个方法，而是当做一个属性。并且实现了这个方法要加上override 关键字
   override var description:String{
        get{
           return String(format: "name is %@, age is %d, score is %d", self.name , self.age ,self.score)
        }
    }
    
    init(name:String , age: Int, score: Int){
        
//        super.init() // nsobject 类没有name 等属性，这里吧注释去掉就不报错？ 可是违背了swift 的初始化规则 --> 特例？？？
        self.name = name
        self.age = age
        self.score = score
    }
    
    
    
    func run(){
        print("person ---run")
    }
    
    class func eat(){
        print("person +++ eat")
    }
    
    
}
