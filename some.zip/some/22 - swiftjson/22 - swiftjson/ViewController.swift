//
//  ViewController.swift
//  22 - swiftjson
//
//  Created by meng on 16/1/25.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit
import SwiftyJSON


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        print("----")
        if let file = NSBundle.mainBundle().pathForResource("Tests", ofType: "json"){
            let d = NSData(contentsOfFile: file)
            let json = JSON(data: d!)
            
//            for (idx , obj) in json{
//                print("\(idx)  \(obj)")
//            }
//            print(json[2])
            
//            print(json)
//            print(json[2]["user"]["profile_image_url"])
//            print(json[2]["user"]["entities"]["url"]["urls"].first)
            print(json[1])
            
        }
        
        
    }

}

