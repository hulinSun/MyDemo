//
//  ViewController.swift
//  03 - GCD定时器
//
//  Created by meng on 16/1/24.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer: dispatch_source_t?
    
    var count: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        apply()
        
    }
    
    /**
     快速迭代
     */
    func apply(){
        
        //注意，这里放主线程的话，那么就不会走
        dispatch_apply(100, dispatch_get_global_queue(0, 0)) { (idx) -> Void in
            
            // idx 顺序是随机的。并且，都是在异步队列中，开了多条线程,但是也有可能是在子线程执行.
            // 迭代100 次并不意味着创建100 条子线程。他会更具cpu 的负载程度来开辟子线程
            print("执行5次代码\(NSThread.currentThread()) \(idx)")
        }
        
        // 这里有个需要注意的是，dispatch_apply这个是会阻塞主线程的。这个log打印会在dispatch_apply都结束后才开始执行
        // dispatch_apply能避免线程爆炸，因为GCD会管理并发,不管你有多少条线程，GCD内部会帮我们管理
        print("apply阻塞主线程会阻塞主线程")
        
    }

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        // 创建定时器
        
        let queue = dispatch_get_main_queue()
        
        //创建一个定时器(dispatch_source_t本质还是个OC对象)
        timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue)
        
        // 设置定时器的各种属性（几时开始任务，每隔多长时间执行一次）
        // GCD的时间参数，一般是纳秒（1秒 == 10的9次方纳秒）
        // 何时开始执行第一个任务
        // dispatch_time(DISPATCH_TIME_NOW, 1.0 * NSEC_PER_SEC) 比当前时间晚3秒
        
        let start = dispatch_time(DISPATCH_TIME_NOW, Int64(1.0) * Int64(NSEC_PER_SEC))
        
        let interv = UInt64(1.0) * UInt64(NSEC_PER_SEC)
        
        // 开启定时器
        dispatch_source_set_timer(timer!, start, interv, 0)
        
        // 设置定时器回调
        dispatch_source_set_event_handler(timer!) { () -> Void in
            self.count++
            print("dispatch_source_set_event_handler\(NSThread.currentThread())")
            
            if self.count == 5{ // 取消定时器
                dispatch_source_cancel(self.timer!)
                
            }
        }
        
        //启动
        dispatch_resume(timer!)

    }


}

