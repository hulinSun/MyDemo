//
//  ViewController.swift
//  01 - runloop简单概念
//
//  Created by meng on 16/1/24.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    /**
     runloop简单实用
     */
    func runloop(){
        
        // 两套api：NSRunloop CFRunloopRef
        
        /**
        1.基本作用
        * 保持程序的持续运行
        * 处理App中的各种事件(比如触摸事件、定时器事件、Selector事件)
        * 节省CPU资源,提高程序性能:该做事时做事,该休息时休息
        
        2.UIApplicationMain函数一直没有返回,保持了程序的持续运行
        * UIApplicationMain 内部自动创建了mainRunloop这个默认启动的RunLoop是跟主线程相关联的
        
        3. runloop 和线程的关系： 一一对应。主线程会默认创建runloop 并且启动。子线程不会自动创建runloop。需要手动创建
        * RunLoop在第一次获取时创建,在线程结束时销毁
        * runloop 在CoreFoundation 中。与线程是一一对应的。体现在一个字典中 [线程对象：runloop对象]
        */
        
        NSRunLoop.currentRunLoop() // 获取当前runloop
        NSRunLoop.mainRunLoop() // 获取主线程的runloop
        
        CFRunLoopGetCurrent()
        CFRunLoopGetMain()
        
        // runloop 相关类
        /**
        * CFRunLoopRef runloop 对象
        * CFRunLoopModeRef runloop 的运行模式
        * CFRunLoopSourceRef 事件源，输入源
        * CFRunLoopTimerRef 类似于定时器
        * CFRunLoopObserverRef 监听者，监听runloop 的状态改变
        */
        
        /**
         * 一个RunLoop包含若干个Mode,每个Mode又包含若干个Source/Timer/Observer
        * 每次RunLoop启动时,只能指定其中一个Mode,这个Mode被称作CurrentMode
        * 如果需要切换Mode,只能退出Loop,再重新指定一个Mode进入
        * 这样做主要是为了分隔开不同组的Source/Timer/Observer,让其互不影响
        * 系统注册了5 个runloop的模式:
        > kCFRunLoopDefaultMode(app运行的默认模式)
        > UITrackingRunLoopMode:界面跟踪 Mode,用于 ScrollView 追踪触摸滑动,保证 界面滑动时不受其他 Mode 影响
        > kCFRunLoopCommonModes: 这是一个占位用的Mode,不是一种真正的Mode,不算真正意义上的mode 代表着前两者
        > UIInitializationRunLoopMode: 在刚启动 App 时第进入的第一个 Mode,启动完成后 就不再使用
        > GSEventReceiveRunLoopMode: 接受系统事件的内部 Mode,通常用不到
        
        */
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

