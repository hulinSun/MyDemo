//
//  ViewController.swift
//  02 - observer
//
//  Created by meng on 16/1/24.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        addObserver()
        time2()
    }

    /**
     创建监听者
     */
    func addObserver(){
        
        let obs = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.AllActivities.rawValue, true, 0) { (runloopObserver, activity) -> Void in
          print("runloop 状态改变\(activity)")
        }
        // 添加观察者：监听RunLoop的状态
        CFRunLoopAddObserver( CFRunLoopGetCurrent(), obs, kCFRunLoopDefaultMode)
        
        // 释放 ????
    }
    
    
    /**
     添加定时器
     */
    func time2(){
        
        let timer2 = NSTimer(timeInterval: 1, target: self, selector: "run", userInfo: nil, repeats: true)
        
        NSRunLoop.currentRunLoop().addTimer(timer2, forMode: NSRunLoopCommonModes)
        
    }
    
    func run(){
        print("---run")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

