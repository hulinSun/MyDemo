//
//  ViewController.swift
//  20 - 解析xml
//
//  Created by meng on 16/1/24.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,NSXMLParserDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    private lazy var url: NSURL? = {
        let i = NSURL(string: "http://120.25.226.186:32812/video?type=XML")
        return i
    }()
    
    private lazy var session: NSURLSession = {
        let i = NSURLSession.sharedSession()
        return i
    }()


    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        // 发送请求
        let task = session.dataTaskWithURL(url!) { (data, response, error) -> Void in
            let parse: NSXMLParser = NSXMLParser(data: data!)
            parse.delegate = self
            parse.parse()
        }
        task.resume()
    }

    // 代理
    
    // 解析到最后一个节点
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        print(elementName)
    }
    
    // 开始解析到第一个节点
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        if elementName == "videos"{
            print("解析到第一个大的")
        }else{
           print(attributeDict)
        }
    }
    
    func parserDidEndDocument(parser: NSXMLParser) {
        print("解析结束")
    }
    
    func parserDidStartDocument(parser: NSXMLParser) {
        print("开始解析")
    }

}

