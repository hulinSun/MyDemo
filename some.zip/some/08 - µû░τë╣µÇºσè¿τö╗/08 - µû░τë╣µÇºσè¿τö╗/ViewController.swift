//
//  ViewController.swift
//  08 - 新特性动画
//
//  Created by meng on 15/12/31.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UIScrollViewDelegate{

    @IBOutlet weak var boyView: UIImageView!
    @IBOutlet weak var sunView: UIImageView!
    
    // scrollView
    private lazy var scrolllView: UIScrollView = {
        let i = UIScrollView()
        i.delegate = self
        return i
    }()

    // 背景
    private lazy var bgView: UIImageView = {
        let i = UIImageView(image: UIImage(named:"520_userguid_bg" ))
        
        return i
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        bgView.frame.size.height = view.frame.size.height
        scrolllView.frame = view.bounds
        scrolllView.decelerationRate = 0.5
        // 添加到scrollView
        scrolllView.addSubview(bgView)
        scrolllView.contentSize = (bgView.image?.size)!
        view.insertSubview(scrolllView, atIndex: 0)
        
    }
    
    // 监听滚动
    func scrollViewDidScroll(scrollView: UIScrollView) {
    
        // 获取offset
        let offsetX = scrolllView.contentOffset.x
        
        let imgName:String = String(format: "520_userguid_person_taitou_%d", Int(offsetX) % 2 + 1)
        boyView.image = UIImage(named: imgName)
        
//         (5) / 180.0 * M_PI
        let angle: CGFloat = CGFloat(5) / CGFloat(180.0) * CGFloat(M_PI)
        
        sunView.transform = CGAffineTransformRotate(sunView.transform, angle);
    }

}

