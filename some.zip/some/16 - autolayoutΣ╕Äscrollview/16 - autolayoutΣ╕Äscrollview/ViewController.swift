//
//  ViewController.swift
//  16 - autolayout与scrollview
//
//  Created by meng on 16/1/15.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /** 1。新建一个scrollView 的约束
            2. 垫一个containerView. 先铺满scrollView
            3. 然后containerView 与self.view 等宽。在蛇者containerView 的高度为1000
            4. 这样就孤立了scrollView。接下来只需要子控件一containerView 之间的约束就好了。摆脱了scrollView 的contentsize 的问题
        */
        
    }
}

