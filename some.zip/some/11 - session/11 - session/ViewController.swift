//
//  ViewController.swift
//  11 - session
//
//  Created by meng on 16/1/11.
//  Copyright © 2016年 meng. All rights reserved.
//  Session 的简单使用

import UIKit

enum Error: ErrorType { // 异常类型
    case InvalidJSON
}

//guard let jsonDict = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments) as? [String : AnyObject] else {
//    throw Error.InvalidJSON
//}

// MARK: - 注意这里的代理方法

class ViewController: UIViewController,NSURLSessionDataDelegate, NSURLConnectionDataDelegate {

    private lazy var url: NSURL? = {
        let url = NSURL(string: "http://jiangsu.china.com.cn/uploadfile/2015/1102/1446443026382534.jpg")
        return url
    }()
    
    private lazy var imgView: UIImageView = {
        let i = UIImageView()
        return i
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgView.frame = CGRectMake(30, 30, 300, 400)
        imgView.contentMode = .Center
        view.addSubview(imgView)
        
//        session1()
        session2()
//        sessionPost()
//        download()
        
    }
    
    /**
     方式1block 是回调
     */
    func session1(){
        let session = NSURLSession.sharedSession()
        
        let dataTask: NSURLSessionDataTask = session.dataTaskWithURL(url!) { (data, response, error) -> Void in
            
            if let d = data{
                // 转图片
                let img: UIImage = UIImage(data: d)!
                // 主线程
                let mainQueue = NSOperationQueue.mainQueue()
                
                let op = NSBlockOperation(block: { () -> Void in
                    self.imgView.image = img
                })
                mainQueue.addOperation(op)
            }
        }
        dataTask.resume()
    }
    
    /**
     代理
     */
    func session2(){
        let cfg = NSURLSessionConfiguration.defaultSessionConfiguration()
        let session = NSURLSession(configuration: cfg, delegate: self, delegateQueue: NSOperationQueue())
        let task = session.dataTaskWithURL(url!)
        task.resume()
    }
    
    
    /**
     post 方式
     */
    func sessionPost(){
        
        let session = NSURLSession.sharedSession()
        
        let url = NSURL(string: "http://120.25.226.186:32812/login")
        let request = NSMutableURLRequest(URL: url!)
        
        request.HTTPMethod = "POST" // POST方法,请求方法
        let  str: NSString = "username=520it&pwd=520it"
        request.HTTPBody = str.dataUsingEncoding(NSUTF8StringEncoding)
        
        let dataTask = session.dataTaskWithRequest(request) { (data, response, error) -> Void in
            
            if let d = data{
                // 转换成str 
//                let s = NSString(data: d, encoding: NSUTF8StringEncoding)
//                print("string is \(s)")
                
                // 转换成字典. try!: 忽略抛出的异常
                let dict: NSDictionary = try! NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableLeaves) as! NSDictionary
                print(dict)
            }
        }
        dataTask.resume()
    }
    
    
    /**
     下载
     */
    func download(){
        
        let session = NSURLSession.sharedSession()
        let ur = NSURL(string: "http://120.25.226.186:32812/resources/videos/minion_01.mp4")
        
        let dataTask = session.downloadTaskWithURL(ur!) { (url, response, error) -> Void in
            // 剪切到文件夹
            if let r = response{
                print(r.suggestedFilename) //Optional("minion_01.mp4")
                
                let saveToFile = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true).last
                
                if let s = saveToFile{
                    let ocs = s as NSString
                    let ocfile = ocs.stringByAppendingPathComponent(r.suggestedFilename!)
                    
                    print(ocfile)
                
                    // 剪切
                    let fileMgr = NSFileManager.defaultManager()
                    
                    do{
                        try fileMgr.moveItemAtURL(url!, toURL: NSURL(fileURLWithPath: ocfile as String))
                    }catch _{
                        print("error")
                    }
                }
            }
        }
        dataTask.resume()
    }
    
    //MARK: delegate
    
    // 请求获得响应 :问题: 为什么来到这个方法就不执行了。下面的方法就不执行了
    
//    func URLSession(session: NSURLSession, dataTask: NSURLSessionDataTask, didReceiveResponse response: NSURLResponse, completionHandler: (NSURLSessionResponseDisposition) -> Void) {
//        
//        print("didReceiveResponse")
//    }
    
    // 开始接收到数据 ，可能会调用多次
    func URLSession(session: NSURLSession, dataTask: NSURLSessionDataTask, didReceiveData data: NSData) {
        
        print(NSThread.currentThread()) // 异步线程
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.imgView.image = UIImage(data: data)
        }
    }
    
    // 下载结束 (成功或者失败)
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didCompleteWithError error: NSError?) {
        print("didCompleteWithError")
        if let e = error{
            print(e)
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

