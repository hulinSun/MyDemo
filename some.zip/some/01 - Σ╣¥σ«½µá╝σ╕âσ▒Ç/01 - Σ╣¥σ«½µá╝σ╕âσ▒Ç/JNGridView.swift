//
//  JNGridView.swift
//  01 - 九宫格布局
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class JNGridView: UIView {

    var shops:[shop]? // 可选的只能用var
    
    
    // 添加子控件
    func addGrid(){
        
        guard subviews.count < 9 else { // 如果 子控件小于16 ，什么也不做，否则直接返回
            return
        }
        
        let v = UIView()
        
        v.backgroundColor = UIColor.grayColor()
        addSubview(v)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let width: CGFloat = 80.0
        let height: CGFloat = 80.0
        let margin: CGFloat = 10.0
        let maxCol = 3
        
        // 取出子控件
        let count = subviews.count
        for i in 0..<count{
           let vi = subviews[i]
           let col = i % maxCol
           let row = i / maxCol
            
            let x = margin + (margin + width) * CGFloat(col)
            let y = margin + (margin + height) * CGFloat(row)
            
            vi.frame = CGRectMake(x, y, width, height)
           
            // 值被传过来了
            if let hashop = shops{
                for item in hashop{
                    print(item.name)
                }
            }
//            UIView.animateWithDuration(0.5, animations: { () -> Void in
//            })
        }
    }
}
