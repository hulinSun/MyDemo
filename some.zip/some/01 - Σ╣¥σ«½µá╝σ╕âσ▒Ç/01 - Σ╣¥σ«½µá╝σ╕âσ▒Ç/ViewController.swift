//
//  ViewController.swift
//  01 - 九宫格布局
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit


class shop{
    
    var name: String
    var icon: String
    
    init(name: String, icon: String){
        self.name = name
        self.icon = icon
    }
    
    init(dict:[String:String]){
        self.name = dict["name"]!
        self.icon = dict["icon"]!
    }
}

class ViewController: UIViewController {

    // MARK: 懒加载
    
    private lazy var addBtn: UIButton = {
        var btn = UIButton()
        btn.backgroundColor = UIColor.redColor()
        btn.setTitle("添加", forState: UIControlState.Normal)
        btn.addTarget(self, action: "addClick", forControlEvents: UIControlEvents.TouchUpInside)
        
        btn.frame = CGRectMake(50,50,44,44)
        btn.layer.cornerRadius = 8
        btn.clipsToBounds = true
        return btn
    }()
    
    private lazy var gridView: JNGridView = {
        var g = JNGridView()
        g.frame = CGRectMake(20,100,300,300)
        g.backgroundColor = UIColor.orangeColor()
        return g
    }()
    
    //MARK: life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(addBtn)
        view.addSubview(gridView)
        shops()
    }
    
    //MARK: eventresponse
    // 添加子子控件
    func addClick(){
        // 添加子控件
        gridView.addGrid()
    }
    
    // 加载plist
    func shops(){
        
        var shops = [shop]()
        
        if let file: String = NSBundle.mainBundle().pathForResource("shops.plist", ofType: nil){
         let array = NSArray(contentsOfFile: file)!
            for item in array as! [[String:String]]{
               let s = shop(dict: item)
                shops.append(s)
            }
        }
        gridView.shops = shops
    }
}

