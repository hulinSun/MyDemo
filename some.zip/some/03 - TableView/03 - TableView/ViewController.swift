//
//  ViewController.swift
//  03 - TableView
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class Hero {
    var icon: String
    var name: String
    var intro: String
    
    init(dict:[String: String]){
        
        self.name = dict["name"]!
        self.icon = dict["icon"]!
        self.intro = dict["intro"]!
    }
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    // 懒加载
    private lazy var tableView: UITableView = {
        let t = UITableView(frame: self.view.bounds, style: UITableViewStyle.Plain)
        return t
    }()
    
    // 数据源数组懒加载
    private lazy var heros: [Hero] = {
        var h:[Hero] = [Hero]()
        
        if let file = NSBundle.mainBundle().pathForResource("heroes.plist", ofType: nil){
            let tempArr: NSArray = NSArray(contentsOfFile: file)!
            for item in tempArr as![[String:String]]{
                let hero: Hero = Hero(dict: item)
                h.append(hero)
            }
        }
        return h
    }()
    
    // 数据源数组
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        view.addSubview(tableView)
        tableView.rowHeight = 60
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return heros.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
         let ident = "cell"
        var cell = tableView.dequeueReusableCellWithIdentifier(ident)
        
        if cell == nil{
            cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: ident)
        }
       // 取出模型
        let hero = heros[indexPath.row]
        cell?.textLabel?.text = hero.name
        cell?.imageView?.image = UIImage(named: hero.icon)
        cell?.detailTextLabel?.text = hero.intro
        
        if indexPath.row % 2 == 0 {
            cell?.accessoryType = .Checkmark
        }else{
            cell?.accessoryType = .DetailDisclosureButton
        }
        
        return cell!
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete{
            
            // 删除数据
            heros.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Left)
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        print("选中了\(indexPath.row) 行")
    }
    
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
}

