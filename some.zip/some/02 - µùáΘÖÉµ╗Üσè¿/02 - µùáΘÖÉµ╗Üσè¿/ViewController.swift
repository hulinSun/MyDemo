//
//  ViewController.swift
//  02 - 无限滚动
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let scrollView = JNScrollView()
        scrollView.backgroundColor = UIColor.greenColor()
        scrollView.frame = CGRectMake(30, 50, 300, 130)
        scrollView.images = [
            UIImage(named: "img_00")!,
            UIImage(named: "img_01")!,
            UIImage(named: "img_02")!,
            UIImage(named: "img_03")!,
            UIImage(named: "img_04")!]
        
        view.addSubview(scrollView)
        
        
    }
    
}

