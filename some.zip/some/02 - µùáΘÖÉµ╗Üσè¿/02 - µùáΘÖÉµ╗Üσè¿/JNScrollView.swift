//
//  JNScrollView.swift
//  02 - 无限滚动
//
//  Created by meng on 15/12/30.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

//extension UIColor {
//    func randomColr()->UIColor{
//        return UIColor(colorLiteralRed: randomFloat(), green: randomFloat(), blue: randomFloat(), alpha: 1)
//    }
//    
//    func randomFloat() -> Float{
//        return (Float(random()) % 255.0) / (255.0)
//    }
//}

class JNScrollView: UIView ,UIScrollViewDelegate{
    
    /*我是一个无限滚动轮播器，那么我需要什么，我就暴露什么，我内部封装的东西，不让别人改。就屏蔽起来 */
    
    
    // 需要图片数组,必须要有
    var images: [UIImage] = [UIImage]() { // 这里给默认值，不然会报错 。存储属性，不能有set get 方法.只能通过did will 来拦截监听
        didSet{
            // 初始化子控件
            let imgCount = images.count
            pageControll.numberOfPages = imgCount
            pageControll.currentPage = 0
            
            for i in 0..<imgCount{
             let imgView = UIImageView()
                imgView.image = images[i]
                scrollView.addSubview(imgView)
            }
        }
    }
    
    // 内部的scrolllView
    private lazy var scrollView: UIScrollView = {
        var s = UIScrollView()
        s.showsHorizontalScrollIndicator = false
        s.showsVerticalScrollIndicator = false
        s.pagingEnabled = true
        s.bounces = false
        return s
    }()
    
    var tmr: NSTimer?
    
    //  内部的pageControll
    private lazy var pageControll: UIPageControl = {
        var p = UIPageControl()
        p.currentPageIndicatorTintColor = UIColor.redColor()
        p.pageIndicatorTintColor = UIColor.blueColor()
        return p
    }()
    
    //MARK: 初始化方法
    init(images: [UIImage]){
       // 有父类，那么必须要调用父类，保证父类初始化成功
        self.images = images
        super.init(frame: CGRectZero) // init() 不是指定构造方法
    }
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        addSubview(scrollView)
        scrollView.delegate = self
        
        addSubview(pageControll)
        addtimer()
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        scrollView.frame = self.bounds
        pageControll.frame = CGRectMake(100, 200, 100, 44)
        
        scrollView.contentSize = CGSizeMake(scrollView.frame.size.width * CGFloat(images.count) , 0);
        
        
        let imgW = self.frame.size.width
        let imgH = self.frame.size.height
        let imgY: CGFloat = 0.0
        
        for i in 0..<images.count{
         let imgView = scrollView.subviews[i]
            let imgX = CGFloat(i) * imgW
            imgView.frame = CGRectMake(imgX, imgY, imgW, imgH)
        }
    }
    
    //MARK: UIScrollViewDelegate
    func scrollViewDidScroll(scrollView: UIScrollView) {
    
        let offsetX = scrollView.contentOffset.x
        pageControll.currentPage =  Int(CGFloat( offsetX ) / scrollView.frame.size.width + 0.5)
    }
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        addtimer()
    }
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        stop()
    }
    
    //MARK: 定时器
    func addtimer(){
        tmr =  NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: "next", userInfo: nil, repeats: true)
        
        NSRunLoop.mainRunLoop().addTimer(tmr!, forMode: NSRunLoopCommonModes)
    }
    
    func stop(){
        tmr?.invalidate()
    }
    
    func next(){
        
        var page = pageControll.currentPage
        if page == 4{
            page = 0
        }else{
            page++
        }
        scrollView.setContentOffset(CGPointMake(CGFloat(page) * scrollView.frame.size.width, 0), animated: true)
        
    }
    
}
