//
//  JNCountButton.swift
//  23 - 倒计时按钮
//
//  Created by meng on 16/1/26.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

 class JNCountButton: UIButton {

    private var timer: dispatch_source_t?
    
    private var count: Int = 0
    
    
    // 这只是简单的小测试。需要考虑的是开启定时。和关闭定时。以及按钮当前状态的通知。
    
    /**
     倒计时按钮
     
     - parameter timeInterval:  多少秒倒计时
     - parameter title:         标题
     - parameter timeOverTitle: 倒计时完毕的标题
     - parameter runningColor:  倒计时显示的颜色
     - parameter timeOverColor: 倒计时完毕之后显示的颜色
     
     */
    init(timeInterval: Int ,title: String , timeOverTitle:String, runningColor:UIColor , timeOverColor: UIColor){
        
        super.init(frame: CGRectZero)
        
        self.count = timeInterval // 保存变量
        
        let queue  = dispatch_get_main_queue()
        
        //创建一个定时器(dispatch_source_t本质还是个对象)
        timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue)
        
        // 设置定时器的各种属性（几时开始任务，每隔多长时间执行一次）
        // GCD的时间参数，一般是纳秒（1秒 == 10的9次方纳秒）
        // 何时开始执行第一个任务
        // dispatch_time(DISPATCH_TIME_NOW, 1.0 * NSEC_PER_SEC) 比当前时间晚3秒
        
        let start = dispatch_time(DISPATCH_TIME_NOW, Int64(1.0) * Int64(NSEC_PER_SEC))
        
        let interv = UInt64(1) * UInt64(NSEC_PER_SEC)
        
        dispatch_source_set_timer(timer!, start, interv, 0)
        
        // 设置定时器回调
        dispatch_source_set_event_handler(timer!) { () -> Void in
            
            print("-----")
            
            // 定时器工作中，那么设置按钮的标题
            self.setTitle(String(format: "%d s", self.count), forState: .Normal)
            self.backgroundColor = runningColor
            self.userInteractionEnabled = false
            
            self.count--
            
            if self.count == -1  { // 结束了
                dispatch_source_cancel(self.timer!)
                dispatch_source_set_cancel_handler(self.timer!, { () -> Void in
                    self.setTitle(timeOverTitle, forState: .Normal)
                    self.backgroundColor = timeOverColor
                    self.userInteractionEnabled = true
                })
            }
        }
        //启动
        dispatch_resume(timer!)
    }
    

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
