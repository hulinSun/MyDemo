//
//  ViewController.swift
//  23 - 倒计时按钮
//
//  Created by meng on 16/1/26.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let btn = JNCountButton(timeInterval: 10, title: "s", timeOverTitle: "请输入验证码", runningColor: UIColor.redColor(), timeOverColor: UIColor.blueColor())
        
        btn.frame = CGRectMake(40, 40, 150, 40)
        btn.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        
        btn.addTarget(self, action: "click", forControlEvents: .TouchUpInside)
        
        view.addSubview(btn)
    }
    
    func click(){
        print("点击了按钮")
    }
    
    
}

