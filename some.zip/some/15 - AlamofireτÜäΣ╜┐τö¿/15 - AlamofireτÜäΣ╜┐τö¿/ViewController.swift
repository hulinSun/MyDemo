//
//  ViewController.swift
//  15 - Alamofire的使用
//
//  Created by meng on 16/1/12.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

import Alamofire

/**
 1:支持链式请求 / 响应 方法
 2:支持URL / JSON / plist 参数编码
 3:支持上传文件 / 数据 /  数据流 / 多个数据
 4:支持下载请求或断点续传
 5:支持NSURLCredential 认证
 6:支持HTTP 响应验证
 7:支持TLS证书公钥Pinning (意味着证书链必须包含处于白名单之中的公钥)
 8:支持扩展闭包和NSProgress (进度报告)
 9:支持cURL 调试输出
 10:支持全方位测试
 11:支持完成文档
*/

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
//        get1()
//        get2()
//        getWithHeader()
//        post1()
//        parameEncodeTest()
//        validate()
//        responseTypeTest()
        test()
    }
    
    /**
     get 例1
     */
    func get1(){
        
        // 其实get 方式可以有参数也可以没有参数。是否有字典取决于url 后面是否有参数
        let parames: Dictionary = ["consumer_key": "消费者密钥"]
        Alamofire.request(.GET, "https://api.500px.com/v1/photos" ,parameters:parames)
        .responseJSON { response -> Void in
            
           print( response.result.value) // 就是responseJSON类型的值
            /**
            Optional({
            error = "Internal Server Error";
            status = 500;
            })
             */
            
           print(response)
            
            print(response.result) // SUCCESS 。成功\失败
        }
        
        // guard 方式
        Alamofire.request(.GET, "https://api.500px.com/v1/photos", parameters: ["consumer_key": "xxxx"]).responseJSON() {
            response in
            guard let JSON = response.result.value else { return }
            print("JSON: \(JSON)")
        }
        
    }
    
    /**
     get  例2
     */
    func get2(){
        
        let parameters:Dictionary = ["key":"93c921ea8b0348af8e8e7a6a273c41bd"]
        
        Alamofire.request(.GET, "http://apis.haoservice.com/weather/city", parameters: parameters)
            .responseJSON { response in
                
                print("result==\(response.result)")   // 返回结果，是否成功
                
                if let jsonValue = response.result.value {
                    /*
                    error_code = 0
                    reason = ""
                    result = 数组套字典的城市列表
                    */
                    print(jsonValue) // 字典

                }
        }
        /*
        result==SUCCESS
        code: Optional(0)
        */
    }
    
    /**
     带有header 的get 方式
     */
    func getWithHeader(){
        
        let headers = ["apikey":"a566eb03378211f7dc9ff15ca78c2d93"]
        Alamofire.request(.GET,"http://apis.baidu.com/heweather/pro/weather?city=beijing", headers: headers)
        .responseJSON { (response) -> Void in
            if let jsonValue = response.result.value{
                print(jsonValue)
            }
        }
    }
    
    /**
     post 例1
     */
    func post1(){
        
        // 使用GET类型请求的时候，参数会自动拼接在url后面，使用POST类型请求的时候，参数是放在在HTTP body里传递，url上看不到的
        
        let parame = ["key":"93c921ea8b0348af8e8e7a6a273c41bd"]
        Alamofire.request(.POST, "http://apis.haoservice.com/weather/city",parameters:parame)
       .responseString { (response) -> Void in // responseString 以字符串类返回
        
            if let jsonstr = response.result.value{
                print(jsonstr)
            }
        }
    }
    
    
    /**
     留言板
     */
    func test(){
        let parame = ["Aid" : "3063" , "page" : "1" , "pageSize" : "10" , "ParentId" : "0" , "Status" : "0" ," Type" : "3"]
        Alamofire.request(.POST, "http://mc.678wsh.com/mtuangou/MtaungouAPI/GetCommnetMessageBoardList" , parameters: parame)
        .responseString { (response) -> Void in
//            if let jsonStr = response.result.value{
//                print(jsonStr)
//            }
            print(response.response?.statusCode)
            print(response.result)
        }
        
    }
    
    /**
     参数编码格式
     */
    func parameEncodeTest(){
//        除了默认的方式外，Alamofire还支持URL、URLEncodedInURL、JSON、Property List以及自定义格式方式编码参数。
        
//        public enum ParameterEncoding {
//            case URL
//            case URLEncodedInURL
//            case JSON
//            case PropertyList(NSPropertyListFormat, NSPropertyListWriteOptions)
//            case Custom((URLRequestConvertible, [String: AnyObject]?) -> (NSMutableURLRequest, NSError?))
//        }
        
        // 比afn更加灵活的体现
        let parameters = [
            "one": [1,2,3],
            "two": ["apple": "pig"]
        ]
        
        Alamofire.request(.POST, "http://www.example.com/service", parameters: parameters, encoding: .JSON)
        .responseString { (response) -> Void in
            if let str = response.result.value{
                print(str)
            }
        }
    }
    
    /**
     validate 测试
     */
    func validate(){
        
//      将其与请求和响应 链接，以确认响应的状态码在默认可接受的范围（200到299）内。如果认证失败，响应处理方法将出现一个相关错误，我们可以根据不同在完成处理方法中处理这个错误。比如下面的样例，成功时会打印成功信息，失败时输出具体错误信息。
        
        Alamofire.request(.GET, "http://apis.haoservice.com/weather/city", parameters: ["apikey":"a566eb03378211f7dc9ff15ca78c2d93"])
            .validate()
            .responseJSON { response in
                switch response.result {
                    
                case .Success:
                    print("数据获取成功!")
                case .Failure(let error):
                    print(error)
                }
        }
    }
    
    /**
     多种响应类型
     */
    func responseTypeTest(){
        // response()
//        responseData()
//        responseString(encoding: NSStringEncoding)
//        responseJSON(options: NSJSONReadingOptions)
//        responsePropertyList(options: NSPropertyListReadOptions)
        
        let parame = ["key":"93c921ea8b0348af8e8e7a6a273c41bd"]
        Alamofire.request(.POST, "http://apis.haoservice.com/weather/city",parameters:parame)
//            .responseString { (response) -> Void in // responseString 以字符串类返回
//    
//            if let jsonstr = response.result.value{
//                print(jsonstr)
//            }
        .responseData { (response) -> Void in
            if let d = response.result.value{
//                print(d.length)
                
                do{
                   let jsonObject = try NSJSONSerialization.JSONObjectWithData(d, options: NSJSONReadingOptions.MutableLeaves)
//                    print(jsonObject.dynamicType) // __NSCFDictionary
                    print(jsonObject)

                    
                }catch _{
                    print("error")
                }
            }
        }
    }
    
    /**
     根据实际情况的一些封装
     */
    func router(){
        
        /** 请求路由
        enum Router: URLRequestConvertible {
            static let baseURLString = "https://api.500px.com/v1"
            static let consumerKey = "消费者密钥"
            
            case PopularPhotos(Int)
            case PhotoInfo(Int, ImageSize)
            case Comments(Int, Int)
            
            var URLRequest: NSMutableURLRequest {
                let result: (path: String, parameters: [String: AnyObject]) = {
                    switch self {
                    case .PopularPhotos(let page):
                        let params = ["consumer_key": Router.consumerKey, "page": "\(page)", "feature": "popular", "rpp": "50",  "include_store": "store_download", "include_states": "votes"]
                        return ("/photos", params)
                    case .PhotoInfo(let photoID, let imageSize):
                        let params = ["consumer_key": Router.consumerKey, "image_size": "\(imageSize.rawValue)"]
                        return ("/photos/\(photoID)", params)
                    case .Comments(let photoID, let commentsPage):
                        let params = ["consumer_key": Router.consumerKey, "comments": "1", "comments_page": "\(commentsPage)"]
                        return ("/photos/\(photoID)/comments", params)
                    }
                }()
                
                let URL = NSURL(string: Router.baseURLString)!
                let URLRequest = NSURLRequest(URL: URL.URLByAppendingPathComponent(result.path))
                let encoding = Alamofire.ParameterEncoding.URL
                
                return encoding.encode(URLRequest, parameters: result.parameters).0
            }
        }
        */
    }
    
    /**
     上传
     */
    func upload(){
        
        // 上传都是post 请求， url  文件
       let fileUrl = NSBundle.mainBundle().URLForResource("test", withExtension: "png")
        if let f = fileUrl{
            Alamofire.upload(.POST, "http://httpbin.org/post", file: f)
        }
    }
    
    /**
     带有上传进度
     */
    func uploadWithProgress(){
        
        let fileURL = NSBundle.mainBundle().URLForResource("Default", withExtension: "png")
        
        Alamofire.upload(.POST, "http://httpbin.org/post", file: fileURL!)
            .progress{ (bytesWritten, totalBytesWritten, totalBytesExpectedToWrite) in
                // 下载进度的回调
                print(totalBytesWritten)
                
        }.responseJSON { (response) -> Void in
            // 上传结果
            print(response)
        }
    }
    
    /**
     下载
     */
    func downLoad(){
        
        // 这个闭包有返回值
        Alamofire.download(.GET, "http://httpbin.org/stream/100", destination: {
            // 给你下载好的路径 和请求响应结果
            (temporaryURL, response) -> NSURL in
            
            if let directoryURL = NSFileManager.defaultManager()
                .URLsForDirectory(.DocumentDirectory,
                    inDomains: .UserDomainMask).last {
                    let pathComponent = response.suggestedFilename
                    return directoryURL.URLByAppendingPathComponent(pathComponent!)
            }
            return temporaryURL
        })
    }
    
    
    /**
     下载，带有下载进度
     */
    func downloadWithProgress(){
        
        Alamofire.download(.GET, "") { (tempUrl, response) -> NSURL in
            if let directoryURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).last{
                return directoryURL.URLByAppendingPathComponent(response.suggestedFilename!)
            }
            return tempUrl
            }
            
            // 下载进度回调
            .progress { (bytesRead, totalBytesRead, totalBytesExpectedToRead) in
                print(totalBytesRead)
        }
        .responseJSON { (response) -> Void in
            if let jsonValue = response.result.value{
                print(jsonValue)
            }
        }
    }
    
    
}

