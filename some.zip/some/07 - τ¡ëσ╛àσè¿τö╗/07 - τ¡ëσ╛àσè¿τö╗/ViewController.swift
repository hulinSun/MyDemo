//
//  ViewController.swift
//  07 - 等待动画
//
//  Created by meng on 15/12/31.
//  Copyright © 2015年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var outerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 创建复制图层
        let replaceL = CAReplicatorLayer()

        replaceL.frame = outerView.bounds
        
        outerView.layer.addSublayer(replaceL)
        
        // 创建小图层
        let smallL = CALayer()
        smallL.transform = CATransform3DMakeScale(0, 0, 0)
        smallL.bounds = CGRectMake(0, 0, 10, 10)
        smallL.cornerRadius = 3
        smallL.masksToBounds = true
        
        smallL.backgroundColor = UIColor.redColor().CGColor
        
        smallL.position = CGPointMake(outerView.bounds.size.width / 2, 20)
        
        replaceL.addSublayer(smallL)
        
        // 缩放动画
        let ainimate = CABasicAnimation()
        ainimate.keyPath = "transform.scale"
        
        ainimate.fromValue = 1
        ainimate.toValue = 0
        ainimate.repeatCount = MAXFLOAT
        let duration: CFTimeInterval = 1
        ainimate.duration = duration
        
        smallL.addAnimation(ainimate, forKey: "small")
        
        let count:CGFloat  = 30
        
        let angel: CGFloat = CGFloat(M_PI) * CGFloat(2) / count
        
        // 设置子层
        replaceL.instanceCount = NSInteger(count)
        replaceL.instanceTransform = CATransform3DMakeRotation(angel, 0, 0, 0.3)
        
        replaceL.instanceDelay = CFTimeInterval(duration) / CFTimeInterval(count)
        
        
    }


}

