//
//  ViewController.swift
//  13 - 大文件断点下载
//
//  Created by meng on 16/1/12.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController,NSURLSessionDownloadDelegate {

    
    private lazy var session: NSURLSession = {
        let i = NSURLSession(configuration: NSURLSessionConfiguration.defaultSessionConfiguration(), delegate: self, delegateQueue:NSOperationQueue())
        
        return i
    }()
    
    // 下载任务
    var task: NSURLSessionDownloadTask?
    
    // 下载恢复data
    var resumeData: NSData?
    
    
    /**
     开始下载
     */
    @IBAction func start(sender: AnyObject) {
        
        task = session.downloadTaskWithURL(NSURL(string: "http://120.25.226.186:32812/resources/videos/minion_01.mp4")!)
        
        task?.resume()
    }
    /**
     暂停下载
     */
    @IBAction func suspend(sender: AnyObject) {
        
        // 一旦这个task被取消了，就无法再恢复
        task?.cancelByProducingResumeData({ resumeData -> Void in
            self.resumeData = resumeData
        })
    }
    
    /**
     继续下载
     */
    @IBAction func goon(sender: AnyObject) {
        task = session.downloadTaskWithResumeData(resumeData!)
        task?.resume()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // 下载错误
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didCompleteWithError error: NSError?) {
        print("didCompleteWithError")
        if let e = error{
            self.resumeData = e.userInfo[NSURLSessionDownloadTaskResumeData] as? NSData
        }
    }
    
    
    // 完成
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didFinishDownloadingToURL location: NSURL) {
        
        let fileMgr = NSFileManager.defaultManager()
        
        let file = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true).last
        if let f = file{
            
            var ocf = f as NSString
            ocf = ocf.stringByAppendingPathComponent((downloadTask.response?.suggestedFilename)!)
            print(ocf)
            do{
                try  fileMgr.moveItemAtURL(location, toURL: NSURL(fileURLWithPath: ocf as String))
            }catch _{
                print("error")
            }
        }
    }
    
    // 进度
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let progress = Double(totalBytesWritten) /  Double(totalBytesExpectedToWrite)
        print("progress = \(progress)")
    }
    
    // 恢复
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {
        
    }

}

