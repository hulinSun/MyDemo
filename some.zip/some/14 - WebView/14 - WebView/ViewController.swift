//
//  ViewController.swift
//  14 - WebView
//
//  Created by meng on 16/1/12.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UIWebViewDelegate{

    @IBOutlet weak var goitem: UIBarButtonItem!
    
    @IBOutlet weak var backItem: UIBarButtonItem!
    @IBOutlet weak var webView: UIWebView!
    
    // 下一页
    @IBAction func go(sender: AnyObject) {
        webView.goForward()
    }
    
    // 返回
    @IBAction func back(sender: AnyObject) {
      webView.goBack()
        
    }
    
    // 刷新
    @IBAction func refresh(sender: AnyObject) {
       webView.reload()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let req = NSURLRequest(URL: NSURL(string: "https://www.baidu.com/")!)
        webView.loadRequest(req)
        
        webView.delegate = self
        
//        webView.pageCount
//        webView.scalesPageToFit
        
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        goitem.enabled = webView.canGoForward
        backItem.enabled = webView.canGoBack
    }
    
    func webViewDidStartLoad(webView: UIWebView) {
        
    }
}

