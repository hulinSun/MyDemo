//
//  ViewController.swift
//  09 - 定时器
//
//  Created by meng on 16/1/5.
//  Copyright © 2016年 meng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // 定时器
    var timer: NSTimer?
    
    var link: CADisplayLink?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addTimer()
        addlink()
    }
    
    /**
     添加定时器
     */
    func addTimer(){
       timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: "run", userInfo: nil, repeats: true)
        NSRunLoop.mainRunLoop().addTimer(timer!, forMode: NSRunLoopCommonModes)
    }
    
    /**
     移除定时器
     */
    func removeTimer(){
        timer?.invalidate()
        timer = nil
    }
    /**
     定时器操作
     */
    func run(){
        print("run ----")
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        removeTimer()
        removeLink()
    }
    
    /**
     添加时钟
     */
    func addlink(){
        
        link = CADisplayLink(target: self, selector: "linkRun")
        // 只有时钟添加到runloop 中才会跑起来
        link!.addToRunLoop(NSRunLoop.mainRunLoop(), forMode:NSRunLoopCommonModes )
    }
    
    func linkRun(){
        print("linkRun-----")
    }
    
    func removeLink(){
        link?.invalidate()
    }
    
}

